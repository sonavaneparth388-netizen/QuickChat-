import os
import requests
import base64

# --- CONFIGURATION ---
USERNAME = "sonavaneparth388-netizen"
TOKEN = "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"

# In dono naam ko check karega taaki 404 error na aaye
REPO_OPTIONS = ["QuickChat", "QuickChat-"]
IGNORE = ["__pycache__", ".git", "uploader.py", "requirement.txt", "README.md"]

def find_working_repo():
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }
    for repo in REPO_OPTIONS:
        url = f"https://api.github.com/repos/{USERNAME}/{repo}"
        res = requests.get(url, headers=headers)
        if res.status_code == 200:
            print(f"📦 Found active repository: '{repo}'")
            return repo
    return None

def upload_project_folders():
    repo = find_working_repo()
    if not repo:
        print("❌ Error: GitHub par 'QuickChat' ya 'QuickChat-' naam ki koi repository nahi mili!")
        print("💡 Ek baar check kijiye ki aapne GitHub par sahi naam se repository banayi hai ya nahi.")
        return

    print("🚀 Scanning project folder and tracking down files inside subfolders...")
    headers = {
        "Authorization": f"token {TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }

    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in IGNORE]
        
        for file in files:
            if file in IGNORE:
                continue
                
            local_path = os.path.relpath(os.path.join(root, file), ".")
            github_path = local_path.replace("\\", "/")
            
            with open(local_path, "rb") as f:
                content = f.read()
                
            url = f"https://api.github.com/repos/{USERNAME}/{repo}/contents/{github_path}"
            
            res = requests.get(url, headers=headers)
            sha = res.json().get("sha") if res.status_code == 200 else None
            
            data = {
                "message": f"Auto-uploading {github_path} from Android",
                "content": base64.b64encode(content).decode("utf-8"),
                "branch": "main"
            }
            if sha:
                data["sha"] = sha
                
            put_res = requests.put(url, headers=headers, json=data)
            if put_res.status_code in [200, 201]:
                print(f"✅ Successfully uploaded: {github_path}")
            else:
                print(f"❌ Failed to upload {github_path}: {put_res.text}")

if __name__ == "__main__":
    upload_project_folders()
    print("🏁 Sync attempt finished!")
