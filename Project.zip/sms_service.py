import os
from twilio.rest import Client

# Your exact Twilio live credentials from your curl request
TWILIO_ACCOUNT_SID = "ACba5ebce52f63adc179f7be8158ad0792"
TWILIO_AUTH_TOKEN = "4191ec42599b7d9ea3d418109d14da97"
MESSAGING_SERVICE_SID = "MGf76dd990bade1e580c39b2cea6132187"

def send_sms_alert(contact_name, phone_number, message_text):
    """
    Sends an actual live text message via your Twilio Messaging Service.
    """
    try:
        # Initialize the live Twilio API client connection
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        
        # Dispatch the message using your MessagingServiceSid across the cellular network
        message = client.messages.create(
            messaging_service_sid=MESSAGING_SERVICE_SID,
            body=f"Alert from Parth: {message_text}",
            to=phone_number
        )
        
        print(f" Live SMS sent to {contact_name}! Message SID: {message.sid}")
        return True
        
    except Exception as e:
        print(f"❌ Twilio Gateway error sending to {contact_name}: {e}")
        return False

def dispatch_to_all(contacts, message_text):
    """
    Loops through your contacts array list and delivers the live broadcast.
    """
    results = []
    success_count = 0
    
    for contact in contacts:
        name = contact.get("name", "Unknown")
        phone = contact.get("phone", "")
        
        if phone:
            success = send_sms_alert(name, phone, message_text)
            if success:
                success_count += 1
            results.append({"name": name, "status": "Sent" if success else "Failed"})
        else:
            results.append({"name": name, "status": "Missing Phone Number"})
            
    return {
        "success": success_count > 0,
        "total_sent": success_count,
        "details": results
    }
